/***********************************************************************************/
/* *********************************** DONNEES *************************************/
/***********************************************************************************/
const rocket = document.getElementById("rocket")
const firingButton = document.getElementById("firing-button")
const billboard = document.getElementById("billboard")
const billboardDisplay = billboard.querySelector("span")

let countdownInterval
let countdownValue = 10

/***********************************************************************************/
/* ********************************** FONCTIONS ************************************/
/***********************************************************************************/

function startCountdown() {
  firingButton.classList.add("disabled")
  firingButton.removeEventListener("click", startCountdown)

  billboardDisplay.textContent = countdownValue

  rocket.src = "images/rocket2.gif"

  countdownInterval = setInterval(updateCountdown, 1000)
}
function updateCountdown() {
  countdownValue--

  billboardDisplay.textContent = countdownValue

  if (countdownValue === 0) {
    clearInterval(countdownInterval)

    launchRocket()
  }
}

function launchRocket() {
  rocket.src = "images/rocket3.gif"
  rocket.classList.add("tookOff")
}

function createStar() {
  const star = document.createElement("div")

  star.classList.add("star")

  const sizes = ["tiny", "normal", "big"]
  const randomSize = sizes[Math.floor(Math.random() * sizes.length)]
  star.classList.add(randomSize)

  star.style.left = `${Math.random() * 100}%`
  star.style.top = `${Math.random() * 100}%`

  document.body.appendChild(star)
}

function createStars(count) {
  for (let i = 0; i < count; i++) {
    createStar()
  }
}

function cancelLaunch() {
  clearInterval(countdownInterval)

  billboardDisplay.textContent = ""

  rocket.src = "images/rocket1.png"

  firingButton.classList.remove("disabled")
  firingButton.addEventListener("click", startCountdown)

  cancelButton.classList.add("disabled")
  cancelButton.removeEventListener("click", cancelLaunch)

  countdownValue = 10
}

function resetLaunch() {
  clearInterval(countdownInterval)

  billboardDisplay.textContent = ""

  rocket.src = "images/rocket1.png"

  rocket.classList.remove("tookOff")

  firingButton.classList.remove("disabled")

  firingButton.removeEventListener("click", startCountdown)

  firingButton.addEventListener("click", startCountdown)

  cancelButton.classList.add("disabled")
  cancelButton.removeEventListener("click", cancelLaunch)

  countdownValue = 10
}

/************************************************************************************/
/* ******************************** CODE PRINCIPAL **********************************/
/************************************************************************************/

// étoiles
createStars(150)

// bouton d'annulation
const cancelButton = document.createElement("img")
cancelButton.id = "cancel-button"
cancelButton.src = "images/cancel-button.png"
cancelButton.alt = "Cancel button"
cancelButton.style.position = "absolute"
cancelButton.style.left = "200px"
cancelButton.style.bottom = "100px"
cancelButton.style.width = "75px"
cancelButton.style.height = "75px"
cancelButton.classList.add("disabled")
document.body.appendChild(cancelButton)

// bouton de réinitialisation
const resetButton = document.createElement("img")
resetButton.id = "reset-button"
resetButton.src = "images/cancel-button.png" // meme image pour simplifier
resetButton.alt = "Reset button"
resetButton.style.position = "absolute"
resetButton.style.left = "300px"
resetButton.style.bottom = "100px"
resetButton.style.width = "75px"
resetButton.style.height = "75px"
document.body.appendChild(resetButton)

firingButton.addEventListener("click", () => {
  startCountdown()

  cancelButton.classList.remove("disabled")
  cancelButton.removeEventListener("click", cancelLaunch)
  cancelButton.addEventListener("click", cancelLaunch)
})

resetButton.addEventListener("click", resetLaunch)
